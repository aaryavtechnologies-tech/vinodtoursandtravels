# Asset provenance

Reference layout and photographs: https://www.tourporlaindia.com/

Brand mark and favicon: created for Vinod Tour and Travels.

Local asset | Original source
--- | ---
assets/60ef7f8691.css | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css
assets/a2b772bcde.ttf | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-brands-400.ttf
assets/ec8d091c63.woff2 | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-brands-400.woff2
assets/9ce40edcb7.ttf | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-regular-400.ttf
assets/bce36e1419.woff2 | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-regular-400.woff2
assets/5d81e55841.ttf | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-solid-900.ttf
assets/004790780a.woff2 | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-solid-900.woff2
assets/fdc2e0a54f.ttf | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-v4compatibility.ttf
assets/17e7c39ae6.woff2 | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-v4compatibility.woff2
assets/5b6b835874.css | https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&display=swap
assets/ae0539e617.css | https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap
assets/912a301517.ttf | https://fonts.gstatic.com/s/dancingscript/v29/If2cXTr6YS-zF4S-kcSWSVi_sxjsohD9F50Ruu7B1i0HTQ.ttf
assets/04e8de1f47.ttf | https://fonts.gstatic.com/s/dancingscript/v29/If2cXTr6YS-zF4S-kcSWSVi_sxjsohD9F50Ruu7B7y0HTQ.ttf
assets/c59c2afd26.ttf | https://fonts.gstatic.com/s/dancingscript/v29/If2cXTr6YS-zF4S-kcSWSVi_sxjsohD9F50Ruu7BAyoHTQ.ttf
assets/c35f5dc801.ttf | https://fonts.gstatic.com/s/dancingscript/v29/If2cXTr6YS-zF4S-kcSWSVi_sxjsohD9F50Ruu7BMSoHTQ.ttf
assets/586a25d99e.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4QK1C4E.ttf
assets/3130e4da0b.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4TC0C4E.ttf
assets/da392f2d7f.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4TC1C4E.ttf
assets/c326995316.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4W61C4E.ttf
assets/94a3ce70d7.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4ZmyC4E.ttf
assets/78e81832ab.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4bC1C4E.ttf
assets/cf784c29a2.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4bCyC4E.ttf
assets/3bd47af1b2.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4deyC4E.ttf
assets/98a6772f45.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4e6yC4E.ttf
assets/17c0a4edee.css | https://www.tourporlaindia.com/assets/css/bootstrap.min.css
assets/0562e8a517.css | https://www.tourporlaindia.com/assets/css/style.css
assets/985040fc62.webp | https://www.tourporlaindia.com/assets/img/about/tourist-img.webp
assets/5c42df6cc6.jpg | https://www.tourporlaindia.com/assets/img/carousel/slider.jpg
assets/33ecc7d844.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-agra/el-mismo-dia-agra-desde-delhi-en-coche/thumbnail-img3.jpg
assets/4d2b9d40a4.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-agra/el-mismo-dia-agra-desde-jaipur-en-coche/thumbnail-img3.jpg
assets/5c575dea5c.webp | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-agra/excurs-n-a-agra-el-mismo-d-a-desde-delhi-en-tren/thumbnail-img3.webp
assets/569b0ca20f.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-agra/tour-nocturno-al-taj-mahal-y-agra-desde-delhi-en-coche/thumbnail-img3.jpg
assets/bba55bdb00.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-rajasthan/rajasthan-con-taj-mahal-12-dias/thumbnail-img.jpg
assets/f3311bd9f6.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-rajasthan/tour-de-15-dias-delhi-bikaner/thumbnail-img3.jpg
assets/db941f0108.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-rajasthan/tour-del-triangulo-dorado-con-amritsar-10-dias/thumbnail-img3.jpg
assets/61fe406efc.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-rajasthan/tour-real-y-clasico-de-rajasthan/thumbnail-img3.jpg
assets/a9dcbe7d3e.webp | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-3-dias/img1.webp
assets/8e99007e2e.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-3-dias/img2.jpg
assets/418df20100.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-3-dias/img5.jpg
assets/8c7c880f55.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-3-dias/thumbnail-img3.jpg
assets/801bfe54da.webp | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-4-dias/thumbnail-img3.webp
assets/d73b56034f.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-5-dias/thumbnail-img3.jpg
assets/10b6ec35a1.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-6-dias/thumbnail-img3.jpg
assets/2518b5b5ae.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/sur-de-la-india/la-maravilla-de-sur-de-la-india/thumbnail-img3.jpg
assets/e0d5c9cb8a.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/sur-de-la-india/sur-de-la-india-con-goa-y-delhi/thumbnail-img3.jpg
assets/13a293f3dc.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/sur-de-la-india/viaje-a-kerala-una-semana/thumbnail-img3.jpg
assets/8c4e619c6f.webp | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/sur-de-la-india/viaje-sur-de-la-india-con-mumbai/thumbnail-img3.webp
assets/b1cef0c381.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/triangulo-de-oro-varanasi/delhi-a-varanasi-tour-de-5-dias-en-tren-expreso/thumbnail-img3.jpg
assets/a20303f3f9.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/triangulo-de-oro-varanasi/tour-del-triangulo-dorado-con-khajuraho-y-varanasi/thumbnail-img3.jpg
assets/29544df022.webp | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/triangulo-de-oro-varanasi/tour-del-triangulo-dorado-con-varanasi-6-dias/thumbnail-img.webp
assets/48195d7572.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/triangulo-de-oro-varanasi/triangulo-de-oro-con-varanasi/thumbnail-img3.jpg
assets/841e157383.webp | https://www.tourporlaindia.com/assets/img/others/Tour-Por-La-India- Mejor-Propuesta-home-view-3/Tour-Por-India-Mejor-Propuesta.webp
assets/22ca898b49.webp | https://www.tourporlaindia.com/assets/img/others/animate_home_view-5/img_001.webp
assets/795cd877bb.webp | https://www.tourporlaindia.com/assets/img/others/animate_home_view-5/img_002.webp
assets/f50ec85d86.jpg | https://www.tourporlaindia.com/assets/img/others/blogs/ranthambore-img-2.jpg
assets/a746016622.jpg | https://www.tourporlaindia.com/assets/img/others/blogs/ranthambore.jpg
assets/c259f7397e.jpg | https://www.tourporlaindia.com/assets/img/others/blogs/varanasi.jpg
assets/cce9ceb467.jpg | https://www.tourporlaindia.com/assets/img/others/capture/Capture_1.jpg
assets/fa4918ad6c.jpg | https://www.tourporlaindia.com/assets/img/others/capture/Capture_2.jpg
assets/ff5a72984b.jpg | https://www.tourporlaindia.com/assets/img/others/capture/Capture_3.jpg
assets/80f4d70ee4.jpg | https://www.tourporlaindia.com/assets/img/others/capture/Capture_4.jpg
assets/98bc735f79.jpg | https://www.tourporlaindia.com/assets/img/others/home_veiw_1/Festival-de-Colores-img-1.jpg
assets/4cc249295f.jpg | https://www.tourporlaindia.com/assets/img/others/home_veiw_1/Triangulo-de-oro-img-3.jpg
assets/6b8ce64476.jpg | https://www.tourporlaindia.com/assets/img/others/home_veiw_1/Triangulo-de-oro-varanasi-img-4.jpg
assets/338743c16e.jpg | https://www.tourporlaindia.com/assets/img/others/home_veiw_1/Vijade-img-2.jpg
assets/afd777cfac.jpg | https://www.tourporlaindia.com/assets/img/others/home_veiw_2/north-img-2.jpg
assets/da5acd51ae.jpg | https://www.tourporlaindia.com/assets/img/others/home_veiw_2/rec-img-2.jpg
assets/afcd02417e.jpg | https://www.tourporlaindia.com/assets/img/others/home_veiw_2/south-img-1.jpg
assets/b9856fda82.jpg | https://www.tourporlaindia.com/assets/img/others/home_veiw_2/taj-mahal-img-4.jpg
