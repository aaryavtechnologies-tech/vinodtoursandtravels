# Asset provenance

Reference layout and photographs: https://www.tourporlaindia.com/

Brand mark and favicon: created for Vinod Tour and Travels.

Local asset | Original source
--- | ---
assets/60ef7f8691.css | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css
assets/a2b772bcde.ttf | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-brands-400.ttf
assets/ec8d091c63.woff2 | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-brands-400.woff2
assets/9ce40edcb7.ttf | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-regular-400.ttf
assets/bce36e1419.woff2 | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-regular-400.woff2
assets/5d81e55841.ttf | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-solid-900.ttf
assets/004790780a.woff2 | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-solid-900.woff2
assets/fdc2e0a54f.ttf | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-v4compatibility.ttf
assets/17e7c39ae6.woff2 | https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/webfonts/fa-v4compatibility.woff2
assets/5b6b835874.css | https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&display=swap
assets/ae0539e617.css | https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&display=swap
assets/912a301517.ttf | https://fonts.gstatic.com/s/dancingscript/v29/If2cXTr6YS-zF4S-kcSWSVi_sxjsohD9F50Ruu7B1i0HTQ.ttf
assets/04e8de1f47.ttf | https://fonts.gstatic.com/s/dancingscript/v29/If2cXTr6YS-zF4S-kcSWSVi_sxjsohD9F50Ruu7B7y0HTQ.ttf
assets/c59c2afd26.ttf | https://fonts.gstatic.com/s/dancingscript/v29/If2cXTr6YS-zF4S-kcSWSVi_sxjsohD9F50Ruu7BAyoHTQ.ttf
assets/c35f5dc801.ttf | https://fonts.gstatic.com/s/dancingscript/v29/If2cXTr6YS-zF4S-kcSWSVi_sxjsohD9F50Ruu7BMSoHTQ.ttf
assets/586a25d99e.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4QK1C4E.ttf
assets/3130e4da0b.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4TC0C4E.ttf
assets/da392f2d7f.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4TC1C4E.ttf
assets/c326995316.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4W61C4E.ttf
assets/94a3ce70d7.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4ZmyC4E.ttf
assets/78e81832ab.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4bC1C4E.ttf
assets/cf784c29a2.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4bCyC4E.ttf
assets/3bd47af1b2.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4deyC4E.ttf
assets/98a6772f45.ttf | https://fonts.gstatic.com/s/outfit/v15/QGYyz_MVcBeNP4NjuGObqx1XmO1I4e6yC4E.ttf
assets/17c0a4edee.css | https://www.tourporlaindia.com/assets/css/bootstrap.min.css
assets/0562e8a517.css | https://www.tourporlaindia.com/assets/css/style.css
assets/985040fc62.webp | https://www.tourporlaindia.com/assets/img/about/tourist-img.webp
assets/33ecc7d844.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-agra/el-mismo-dia-agra-desde-delhi-en-coche/thumbnail-img3.jpg
assets/4d2b9d40a4.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-agra/el-mismo-dia-agra-desde-jaipur-en-coche/thumbnail-img3.jpg
assets/5c575dea5c.webp | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-agra/excurs-n-a-agra-el-mismo-d-a-desde-delhi-en-tren/thumbnail-img3.webp
assets/569b0ca20f.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-agra/tour-nocturno-al-taj-mahal-y-agra-desde-delhi-en-coche/thumbnail-img3.jpg
assets/bba55bdb00.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-rajasthan/rajasthan-con-taj-mahal-12-dias/thumbnail-img.jpg
assets/f3311bd9f6.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-rajasthan/tour-de-15-dias-delhi-bikaner/thumbnail-img3.jpg
assets/db941f0108.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-rajasthan/tour-del-triangulo-dorado-con-amritsar-10-dias/thumbnail-img3.jpg
assets/61fe406efc.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/paquetes-tur-sticos-de-rajasthan/tour-real-y-clasico-de-rajasthan/thumbnail-img3.jpg
assets/a9dcbe7d3e.webp | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-3-dias/img1.webp
assets/8e99007e2e.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-3-dias/img2.jpg
assets/418df20100.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-3-dias/img5.jpg
assets/8c7c880f55.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-3-dias/thumbnail-img3.jpg
assets/801bfe54da.webp | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-4-dias/thumbnail-img3.webp
assets/d73b56034f.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-5-dias/thumbnail-img3.jpg
assets/10b6ec35a1.jpg | https://www.tourporlaindia.com/assets/img/itnary/paquetes-tur-sticos/tour-del-tr-ngulo-dorado/tour-triangulo-dorado-6-dias/thumbnail-img3.jpg
assets/2518b5b5ae.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/sur-de-la-india/la-maravilla-de-sur-de-la-india/thumbnail-img3.jpg
assets/e0d5c9cb8a.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/sur-de-la-india/sur-de-la-india-con-goa-y-delhi/thumbnail-img3.jpg
assets/13a293f3dc.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/sur-de-la-india/viaje-a-kerala-una-semana/thumbnail-img3.jpg
assets/8c4e619c6f.webp | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/sur-de-la-india/viaje-sur-de-la-india-con-mumbai/thumbnail-img3.webp
assets/b1cef0c381.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/triangulo-de-oro-varanasi/delhi-a-varanasi-tour-de-5-dias-en-tren-expreso/thumbnail-img3.jpg
assets/a20303f3f9.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/triangulo-de-oro-varanasi/tour-del-triangulo-dorado-con-khajuraho-y-varanasi/thumbnail-img3.jpg
assets/29544df022.webp | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/triangulo-de-oro-varanasi/tour-del-triangulo-dorado-con-varanasi-6-dias/thumbnail-img.webp
assets/48195d7572.jpg | https://www.tourporlaindia.com/assets/img/itnary/tour-de-aventura/triangulo-de-oro-varanasi/triangulo-de-oro-con-varanasi/thumbnail-img3.jpg
assets/f50ec85d86.jpg | https://www.tourporlaindia.com/assets/img/others/blogs/ranthambore-img-2.jpg
assets/a746016622.jpg | https://www.tourporlaindia.com/assets/img/others/blogs/ranthambore.jpg
assets/c259f7397e.jpg | https://www.tourporlaindia.com/assets/img/others/blogs/varanasi.jpg
assets/b9856fda82.jpg | https://www.tourporlaindia.com/assets/img/others/home_veiw_2/taj-mahal-img-4.jpg

## Owner-supplied traveller photographs

All 43 owner-supplied photos from images.zip and the additional WhatsApp ZIP files are included in the traveller gallery.

Local asset | Supplied filename
--- | ---
assets/traveller-photos/travel-01.jpeg | WhatsApp Image 2026-09-17 at 2.22.35 PM.jpeg
assets/traveller-photos/travel-02.jpeg | WhatsApp Image 2026-09-17 at 2.22.39 PM.jpeg
assets/traveller-photos/travel-03.jpeg | WhatsApp Image 2026-09-17 at 2.22.40 PM (1).jpeg
assets/traveller-photos/travel-04.jpeg | WhatsApp Image 2026-09-17 at 2.22.40 PM.jpeg
assets/traveller-photos/travel-05.jpeg | WhatsApp Image 2026-09-17 at 2.22.41 PM.jpeg
assets/traveller-photos/travel-06.jpeg | WhatsApp Image 2026-09-17 at 2.22.42 PM.jpeg
assets/traveller-photos/travel-07.jpeg | WhatsApp Image 2026-09-17 at 2.22.43 PM (1).jpeg
assets/traveller-photos/travel-08.jpeg | WhatsApp Image 2026-09-17 at 2.22.43 PM.jpeg
assets/traveller-photos/travel-09.jpeg | WhatsApp Image 2026-09-17 at 2.22.44 PM (1).jpeg
assets/traveller-photos/travel-10.jpeg | WhatsApp Image 2026-09-17 at 2.22.44 PM.jpeg
assets/traveller-photos/travel-11.jpeg | WhatsApp Image 2026-09-17 at 2.22.45 PM (1).jpeg
assets/traveller-photos/travel-12.jpeg | WhatsApp Image 2026-09-17 at 2.22.45 PM.jpeg
assets/traveller-photos/travel-13.jpeg | WhatsApp Image 2026-09-17 at 2.22.47 PM.jpeg
assets/traveller-photos/travel-14.jpeg | WhatsApp Image 2026-09-17 at 2.22.19 PM.jpeg
assets/traveller-photos/travel-15.jpeg | WhatsApp Image 2026-09-17 at 2.22.20 PM.jpeg
assets/traveller-photos/travel-16.jpeg | WhatsApp Image 2026-09-17 at 2.22.21 PM.jpeg
assets/traveller-photos/travel-17.jpeg | WhatsApp Image 2026-09-17 at 2.22.31 PM (1).jpeg
assets/traveller-photos/travel-18.jpeg | WhatsApp Image 2026-09-17 at 2.22.31 PM.jpeg
assets/traveller-photos/travel-19.jpeg | WhatsApp Image 2026-09-17 at 2.22.32 PM (1).jpeg
assets/traveller-photos/travel-20.jpeg | WhatsApp Image 2026-09-17 at 2.22.32 PM.jpeg
assets/traveller-photos/travel-21.jpeg | WhatsApp Image 2026-09-17 at 2.22.33 PM.jpeg
assets/traveller-photos/travel-22.jpeg | WhatsApp Image 2026-09-17 at 2.22.34 PM.jpeg
assets/traveller-photos/travel-23.jpeg | WhatsApp Image 2026-09-17 at 2.22.35 PM (1).jpeg
assets/traveller-photos/travel-24.jpeg | WhatsApp Image 2026-09-17 at 2.11.59 PM.jpeg
assets/traveller-photos/travel-25.jpeg | WhatsApp Image 2026-09-17 at 2.12.00 PM.jpeg
assets/traveller-photos/travel-26.jpeg | WhatsApp Image 2026-09-17 at 2.12.00 PM (1).jpeg
assets/traveller-photos/travel-27.jpeg | WhatsApp Image 2026-09-17 at 2.10.05 PM.jpeg
assets/traveller-photos/travel-28.jpeg | WhatsApp Image 2026-09-17 at 2.10.06 PM.jpeg
assets/traveller-photos/travel-29.jpeg | WhatsApp Image 2026-09-17 at 2.10.06 PM (1).jpeg
assets/traveller-photos/travel-30.jpeg | WhatsApp Image 2026-09-17 at 2.10.07 PM.jpeg
assets/traveller-photos/travel-31.jpeg | WhatsApp Image 2026-09-17 at 2.10.07 PM (1).jpeg
assets/traveller-photos/travel-32.jpeg | WhatsApp Image 2026-09-17 at 2.10.07 PM (2).jpeg
assets/traveller-photos/travel-33.jpeg | WhatsApp Image 2026-09-17 at 2.10.08 PM.jpeg
assets/traveller-photos/travel-34.jpeg | WhatsApp Image 2026-09-17 at 2.10.08 PM (1).jpeg
assets/traveller-photos/travel-35.jpeg | WhatsApp Image 2026-09-17 at 2.10.09 PM.jpeg
assets/traveller-photos/travel-36.jpeg | WhatsApp Image 2026-09-17 at 2.10.09 PM (1).jpeg
assets/traveller-photos/travel-37.jpeg | WhatsApp Image 2026-09-17 at 2.10.09 PM (2).jpeg
assets/traveller-photos/travel-38.jpeg | WhatsApp Image 2026-09-17 at 2.10.10 PM.jpeg
assets/traveller-photos/travel-39.jpeg | WhatsApp Image 2026-09-17 at 2.10.10 PM (1).jpeg
assets/traveller-photos/travel-40.jpeg | WhatsApp Image 2026-09-17 at 3.25.28 PM.jpeg
assets/traveller-photos/travel-41.jpeg | WhatsApp Image 2026-09-17 at 3.25.51 PM.jpeg
assets/traveller-photos/travel-42.jpeg | WhatsApp Image 2026-09-17 at 3.26.23 PM.jpeg
assets/traveller-photos/travel-43.jpeg | WhatsApp Image 2026-09-17 at 3.26.58 PM.jpeg

## Destination photographs

See photo-credits.html for visible credits and original license links.

assets/destinations/manali.jpg | Neerajsinghazm | CC BY-SA 4.0 | https://commons.wikimedia.org/wiki/File:Manali_City.jpg | https://creativecommons.org/licenses/by-sa/4.0
assets/destinations/shimla.jpg | Navneet Sharma | CC BY-SA 4.0 | https://commons.wikimedia.org/wiki/File:Landscape_of_Shimla_,_Himachal_Pradesh.jpg | https://creativecommons.org/licenses/by-sa/4.0
assets/destinations/chandigarh.jpg | Raakesh Blokhra | CC BY-SA 2.0 | https://commons.wikimedia.org/wiki/File:Open_Hand_monument,_Chandigarh.jpg | https://creativecommons.org/licenses/by-sa/2.0
assets/destinations/amritsar.jpg | Shagil Kannur | CC BY-SA 4.0 | https://commons.wikimedia.org/wiki/File:The_Golden_Temple_of_Amrithsar_7.jpg | https://creativecommons.org/licenses/by-sa/4.0
assets/destinations/char-dham.jpg | Shivam Kumar 766 | CC BY-SA 4.0 | https://commons.wikimedia.org/wiki/File:Kedarnath_Temple_in_Rainy_season.jpg | https://creativecommons.org/licenses/by-sa/4.0
assets/destinations/haridwar.jpg | Sanatansociety Picture provided by Peter and Chris Marchand, provides free information for promotional purpose | CC BY-SA 2.5 | https://commons.wikimedia.org/wiki/File:Evening_view_of_Har-ki-Pauri,_Haridwar.jpg | https://creativecommons.org/licenses/by-sa/2.5
assets/destinations/rishikesh.jpg | VK1983 | CC BY-SA 4.0 | https://commons.wikimedia.org/wiki/File:Trayambakeshwar_Temple_VK.jpg | https://creativecommons.org/licenses/by-sa/4.0
assets/destinations/mussoorie.jpg | Paul Hamilton | CC BY-SA 2.0 | https://commons.wikimedia.org/wiki/File:Mussoorie_Snow_Over_Dehradun_(14831297545).jpg | https://creativecommons.org/licenses/by-sa/2.0
assets/destinations/nainital.jpg | Skalvanov | CC BY-SA 4.0 | https://commons.wikimedia.org/wiki/File:Nainital_metro.jpg | https://creativecommons.org/licenses/by-sa/4.0
assets/destinations/jim-corbett.jpg | Soumyajit Nandy | CC BY-SA 3.0 | https://commons.wikimedia.org/wiki/File:Bengal-Tiger_Corbett_Uttarakhand_Dec-2013.jpg | https://creativecommons.org/licenses/by-sa/3.0
assets/destinations/lansdowne.jpg | Ravi krishnan gupta | CC BY-SA 4.0 | https://commons.wikimedia.org/wiki/File:Lansdowne_Landscape.jpg | https://creativecommons.org/licenses/by-sa/4.0
assets/destinations/delhi.jpg | Incredible India Portal | CC0 | https://commons.wikimedia.org/wiki/File:India_Gate_in_the_Evening.jpg | http://creativecommons.org/publicdomain/zero/1.0/deed.en
assets/destinations/jaipur.jpg | Chainwit. | CC BY-SA 4.0 | https://commons.wikimedia.org/wiki/File:East_facade_Hawa_Mahal_Jaipur_from_ground_level_(July_2022)_-_img_01.jpg | https://creativecommons.org/licenses/by-sa/4.0
assets/destinations/agra-fort.jpg | A.Savin | FAL | https://commons.wikimedia.org/wiki/File:Agra_03-2016_16_Agra_Fort.jpg | http://artlibre.org/licence/lal/en
assets/destinations/qutub-minar.jpg | Wasir kasab | CC BY 4.0 | https://commons.wikimedia.org/wiki/File:Qutb_Minar_2022.jpg | https://creativecommons.org/licenses/by/4.0
assets/destinations/lotus-temple.jpg | Vandelizer | CC BY 2.0 | https://commons.wikimedia.org/wiki/File:LotusDelhi.jpg | https://creativecommons.org/licenses/by/2.0
assets/destinations/taj-mahal.jpeg | Yann ; edited by Jim Carter | CC BY-SA 4.0 | https://commons.wikimedia.org/wiki/File:Taj_Mahal_(Edited).jpeg | https://creativecommons.org/licenses/by-sa/4.0
